from flask import Flask,jsonify,make_response,request,send_from_directory
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS, cross_origin # To handle Cross-Origin Resource Sharing (CORS)
import requests
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes
#CORS(app, supports_credentials=True, resources={r"/*": {"origins": "http://localhost:3000"}})
# Configure SQLite database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///profiles.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 2 * 1024 * 1024  # 2MB max size
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
db = SQLAlchemy(app)

# Ensure the upload folder exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Define the Profile model
class Profile(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    photo = db.Column(db.String(200), nullable=True)
    description = db.Column(db.String(200), nullable=True)
    adress = db.Column(db.String(200), nullable=True)
    

# Initialize the database
def create_tables():
    with app.app_context():
        db.create_all()

# Replace with your Mapbox Access Token
MAPBOX_ACCESS_TOKEN = "pk.eyJ1Ijoib21rYXIyMTExOTYiLCJhIjoiY20zbGF0Y202MG9kbjJscGViOXFqOTVzOSJ9.pytJzzZE9jqg6wWHfHWOew"


# Endpoint to get profiles
@app.route('/api/profiles', methods=['GET'])
def get_profiles():
    profiles = Profile.query.all()
    return jsonify([{
        "id": profile.id,
        "name": profile.name,
        "photo": profile.photo,
        "description": profile.description,
        "adress": profile.adress
    } for profile in profiles])

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

# API endpoint to add a new profile
@app.route('/profiles', methods=['POST'])
def add_profile():
    #data = request.json
    data = request.form
    file = request.files.get('photo')
    filename = None

    # Save the uploaded photo if it exists
    if file:
        filename = secure_filename(file.filename)
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

    new_profile = Profile(
        name=data['name'],
        photo=filename,
        description=data.get('description'),
        adress=data.get('adress'),
        
    )
    db.session.add(new_profile)
    db.session.commit()
    return jsonify({"message": "Profile added successfully!"}), 201

# API endpoint to update a profile
# @app.route('/profiles/<int:id>', methods=['PUT'])
# def update_profile(id):
#     data = request.json
#     profile = Profile.query.get_or_404(id)
#     profile.name = data['name']
#     profile.photo = data.get('photo')
#     profile.description = data.get('description')
#     profile.adress = data.get('adress')
    
#     db.session.commit()
#     return jsonify({"message": "Profile updated successfully!"})


@app.route('/profiles/<int:id>', methods=['PUT'])
def update_profile(id):
    profile = Profile.query.get_or_404(id)

    # Handle data from the request
    name = request.form.get('name', profile.name)
    description = request.form.get('description', profile.description)
    adress = request.form.get('adress', profile.adress)
    photo = profile.photo  # Default to existing photo

    # Handle file upload if a new photo is provided
    if 'photo' in request.files:
        file = request.files['photo']
        if file and file.filename:
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)
            photo = filename  # Update the photo field with the new filename

    # Update profile fields
    profile.name = name
    profile.description = description
    profile.adress = adress
    profile.photo = photo

    db.session.commit()
    return jsonify({"message": "Profile updated successfully!"})

# API endpoint to delete a profile
@app.route('/profiles/<int:id>', methods=['DELETE'])
def delete_profile(id):
    profile = Profile.query.get_or_404(id)
    db.session.delete(profile)
    db.session.commit()
    return jsonify({"message": "Profile deleted successfully!"})

@app.route('/api/geocode', methods=['POST'])
#@cross_origin(origin='*')
def geocode_address():
    data = request.json
    address = data.get('address')

    if not address:
        return jsonify({'error': 'Address is required'}), 400

    url = f"https://api.mapbox.com/geocoding/v5/mapbox.places/{address}.json"
    params = {'access_token': MAPBOX_ACCESS_TOKEN}

    response = requests.get(url, params=params)
    if response.status_code == 200:
        geo_data = response.json()
        if geo_data['features']:
            coordinates = geo_data['features'][0]['geometry']['coordinates']
            print(coordinates[1],coordinates[0])
            #return jsonify({'latitude': coordinates[1], 'longitude': coordinates[0]})
            response = make_response(jsonify({'latitude': coordinates[1], 'longitude': coordinates[0]}))
            response.headers['Access-Control-Allow-Origin'] = '*'
            response.headers['Access-Control-Allow-Methods'] = 'GET, POST'
            response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization'
            return response
        else:
            return jsonify({'error': 'No results found for the address'}), 404
    else:
        return jsonify({'error': 'Failed to fetch geocoding data'}), 500

if __name__ == '__main__':
    create_tables()
    app.run(debug=True)
