const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');


const app = express();
app.use(cors());
app.use(bodyParser.json());

let profiles = [
    {
        id: 1,
        name: "John Doe",
        description: "Software Engineer",
        photo: "https://via.placeholder.com/150",
        address: { lat: 37.7749, lng: -122.4194 },
    },
    {
        id: 2,
        name: "Jane Smith",
        description: "Product Manager",
        photo: "https://via.placeholder.com/150",
        address: { lat: 34.0522, lng: -118.2437 },
    },
];

// Get Profiles
app.get('/profiles', (req, res) => res.json(profiles));

// Add Profile
app.post('/profiles', (req, res) => {
    const newProfile = { id: profiles.length + 1, ...req.body };
    profiles.push(newProfile);
    res.status(201).json(newProfile);
});

// Delete Profile
app.delete('/profiles/:id', (req, res) => {
    profiles = profiles.filter((p) => p.id !== parseInt(req.params.id));
    res.status(204).send();
});

// Start Server
app.listen(5000, () => console.log('Backend running on http://localhost:5000'));
