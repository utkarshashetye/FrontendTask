import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import ProfileList from './components/ProfileList';
import AdminDashboard from './components/AdminDashboard';
import ProfileManagement from './components/ProfileManagement';
const App = () => (
    <Router>
        <Routes>
            <Route path="/" element={<ProfileList />} />
            <Route path="/admin" element={<ProfileManagement />} />
        </Routes>
    </Router>
);

export default App;

