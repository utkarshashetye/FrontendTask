import React, { useState, useEffect } from 'react';
import axios from 'axios';
import MapComponent from './MapComponent';

const ProfileList = () => {
    const [profiles, setProfiles] = useState([]);
    const [selectedProfile, setSelectedProfile] = useState(null);
    const [selectedAddress, setSelectedAddress] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    useEffect(() => {
        axios.get('http://127.0.0.1:5000/api/profiles')
            .then((res) => setProfiles(res.data))
            .catch((err) => console.error(err));
    }, []);

    const handleSummaryClick = (profile) => {
        setLoading(true);
        setError('');
        const data={ address: profile.adress }
    
        axios.post('http://127.0.0.1:5000/api/geocode',data,{headers: {
          'Content-Type': 'application/json',
        },})
          .then((response) => {
            console.log(response.data.latitude)
            setSelectedProfile({
              ...profile,
              latitude: response.data.latitude,
              longitude: response.data.longitude,
            });
          })
          .catch((error) => {
            console.error('Error fetching coordinates:', error);
            setError('Failed to fetch coordinates for the address.');
          })
          .finally(() => {
            setLoading(false);
          });
      };
    
      

    return (
        <div>
            <h1>Profiles</h1>
            <div className="profile-list">
                {profiles.map((profile) => (
                    <div key={profile.id} className="profile-card">
                        {profile.photo && (
                          <img
                            src={`http://127.0.0.1:5000/uploads/${profile.photo}`}
                            alt={profile.name}
                            style={{ width: '100px', height: '100px' }}
                          />
                        )}
                        <h3>{profile.name}</h3>
                        <p>{profile.description}</p>
                        <button onClick={() => handleSummaryClick(profile)}>Summary</button>
                    </div>
                ))}
            </div>
            {loading && <p>Loading map...</p>}
      {error && <p style={{ color: 'red' }}>{error}</p>}
      {selectedProfile && (
        <div>
          <h2>Map for {selectedProfile.name}</h2>
          <MapComponent latitude={selectedProfile.latitude} longitude={selectedProfile.longitude} />
        </div>
      )}
        </div>
    );
};

export default ProfileList;
