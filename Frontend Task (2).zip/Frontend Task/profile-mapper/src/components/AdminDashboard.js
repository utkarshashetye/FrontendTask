import React, { useState } from 'react';
import axios from 'axios';

const AdminDashboard = () => {
    const [profile, setProfile] = useState({ name: '', description: '', photo: '', address: { lat: '', lng: '' } });

    const handleAddProfile = () => {
        axios.post('http://localhost:5000/profiles', profile)
            .then(() => alert('Profile added!'))
            .catch((err) => console.error(err));
    };

    return (
        <div>
            <h1>Admin Dashboard</h1>
            <input
                type="text"
                placeholder="Name"
                onChange={(e) => setProfile({ ...profile, name: e.target.value })}
            />
            <input
                type="text"
                placeholder="Description"
                onChange={(e) => setProfile({ ...profile, description: e.target.value })}
            />
            <input
                type="text"
                placeholder="Photo URL"
                onChange={(e) => setProfile({ ...profile, photo: e.target.value })}
            />
            <input
                type="text"
                placeholder="Latitude"
                onChange={(e) => setProfile({ ...profile, address: { ...profile.address, lat: e.target.value } })}
            />
            <input
                type="text"
                placeholder="Longitude"
                onChange={(e) => setProfile({ ...profile, address: { ...profile.address, lng: e.target.value } })}
            />
            <button onClick={handleAddProfile}>Add Profile</button>
        </div>
    );
};

export default AdminDashboard;
