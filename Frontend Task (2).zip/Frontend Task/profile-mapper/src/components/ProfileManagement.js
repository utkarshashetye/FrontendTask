// import React, { useState, useEffect } from 'react';
// import axios from 'axios';

// const ProfileManagement = () => {
//   const [profiles, setProfiles] = useState([]);
//   const [newProfile, setNewProfile] = useState({
//     name: '',
//     photo: '',
//     description: '',
//     latitude: '',
//     longitude: '',
//   });
//   const [editMode, setEditMode] = useState(false);
//   const [editId, setEditId] = useState(null);

//   // Fetch profiles
//   const fetchProfiles = async () => {
//     const response = await axios.get('http://127.0.0.1:5000/api/profiles');
//     setProfiles(response.data);
//   };

//   useEffect(() => {
//     fetchProfiles();
//   }, []);

//   // Add or Update profile
//   const handleSave = async () => {
//     if (editMode) {
//       await axios.put(`http://127.0.0.1:5000/profiles/${editId}`, newProfile);
//     } else {
//       await axios.post('http://127.0.0.1:5000/profiles', newProfile);
//     }
//     fetchProfiles();
//     setNewProfile({ name: '', photo: '', description: '', adress: '' });
//     setEditMode(false);
//   };

//   // Delete profile
//   const handleDelete = async (id) => {
//     await axios.delete(`http://127.0.0.1:5000/profiles/${id}`);
//     fetchProfiles();
//   };

//   // Edit profile
//   const handleEdit = (profile) => {
//     setNewProfile(profile);
//     setEditMode(true);
//     setEditId(profile.id);
//   };

//   return (
//     <div>
//       <h2>Profile Management</h2>
//       <form onSubmit={(e) => e.preventDefault()}>
//         <input
//           type="text"
//           placeholder="Name"
//           value={newProfile.name}
//           onChange={(e) => setNewProfile({ ...newProfile, name: e.target.value })}
//         />
//         {/* <input
//           type="text"
//           placeholder="Photo URL"
//           value={newProfile.photo}
//           onChange={(e) => setNewProfile({ ...newProfile, photo: e.target.value })}
//         /> */}
//         <input type="file" onChange={(e) => setPhoto(e.target.files[0])} />
//         <textarea
//           placeholder="Description"
//           value={newProfile.description}
//           onChange={(e) => setNewProfile({ ...newProfile, description: e.target.value })}
//         ></textarea>

//         <textarea
//           placeholder="adress"
//           value={newProfile.adress}
//           onChange={(e) => setNewProfile({ ...newProfile, adress: e.target.value })}
//         ></textarea>
        
          
//         <button onClick={handleSave}>{editMode ? 'Update' : 'Add'} Profile</button>
//       </form>
//       <div>
//         <h3>Existing Profiles</h3>
//         {profiles.map((profile) => (
//           <div key={profile.id}>
//             <h4>{profile.name}</h4>
//             <p>{profile.description}</p>
//             <button onClick={() => handleEdit(profile)}>Edit</button>
//             <button onClick={() => handleDelete(profile.id)}>Delete</button>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default ProfileManagement;  


import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ProfileManagement = () => {
  const [profiles, setProfiles] = useState([]);
  const [newProfile, setNewProfile] = useState({
    name: '',
    description: '',
    adress: '',
  });
  const [photo, setPhoto] = useState(null); // Separate state for file handling
  const [editMode, setEditMode] = useState(false);
  const [editId, setEditId] = useState(null);

  // Fetch profiles from the backend
  const fetchProfiles = async () => {
    try {
      const response = await axios.get('http://127.0.0.1:5000/api/profiles');

      console.log(response.data)
      setProfiles(response.data);
    } catch (error) {
      console.error('Error fetching profiles:', error);
    }
  };

  useEffect(() => {
    fetchProfiles();
  }, []);

  // Add or Update profile
  const handleSave = async () => {
    try {
      const formData = new FormData();
      formData.append('name', newProfile.name);
      formData.append('description', newProfile.description);
      formData.append('adress', newProfile.adress);
      if (photo) {
        formData.append('photo', newProfile.photo);
      }

      if (editMode) {
        // Update profile
        await axios.put(`http://127.0.0.1:5000/profiles/${editId}`, formData, {
          headers: { 'Content-Type': 'multipart/form-data' },
        });
      } else {
        // Add new profile
        await axios.post('http://127.0.0.1:5000/profiles', formData, {
          headers: { 'Content-Type': 'multipart/form-data' },
        });
      }

      fetchProfiles();
      setNewProfile({ name: '', description: '', address: '' });
      setPhoto(null);
      setEditMode(false);
    } catch (error) {
      console.error('Error saving profile:', error);
    }
  };

  // Delete profile
  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this profile?')) {
      try {
        await axios.delete(`http://127.0.0.1:5000/profiles/${id}`);
        fetchProfiles();
      } catch (error) {
        console.error('Error deleting profile:', error);
      }
    }
  };

  // Edit profile
  const handleEdit = (profile) => {
    setNewProfile({
      name: profile.name,
      description: profile.description,
      adress: profile.adress,
    });
    setEditId(profile.id);
    setEditMode(true);
    setPhoto(null); // Reset photo for edit mode
  };

  return (
    <div>
      <h2>Profile Management</h2>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSave();
        }}
      >
        <input
          type="text"
          placeholder="Name"
          value={newProfile.name}
          onChange={(e) => setNewProfile({ ...newProfile, name: e.target.value })}
          required
        />
        <textarea
          placeholder="Description"
          value={newProfile.description}
          onChange={(e) => setNewProfile({ ...newProfile, description: e.target.value })}
          required
        ></textarea>
        <textarea
          placeholder="Address"
          value={newProfile.address}
          onChange={(e) => setNewProfile({ ...newProfile, address: e.target.value })}
        ></textarea>
        <input type="file" onChange={(e) => setPhoto(e.target.files[0])} />
        <button type="submit">{editMode ? 'Update' : 'Add'} Profile</button>
      </form>
      <div>
        <h3>Existing Profiles</h3>
        {profiles.map((profile) => (
          <div key={profile.id} style={{ border: '1px solid black', padding: '10px', margin: '10px' }}>
            <h4>{profile.name}</h4>
            <p>Description: {profile.description}</p>
            <p>Address: {profile.address}</p>
            {profile.photo && (
              <img
                src={`http://127.0.0.1:5000/uploads/${profile.photo}`}
                alt={profile.name}
                style={{ width: '100px', height: '100px' }}
              />
            )}
            <div>
              <button onClick={() => handleEdit(profile)}>Edit</button>
              <button onClick={() => handleDelete(profile.id)}>Delete</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProfileManagement;

