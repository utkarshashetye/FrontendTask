import React, { useEffect, useRef } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';

// Replace with your Mapbox access token
mapboxgl.accessToken = "pk.eyJ1Ijoib21rYXIyMTExOTYiLCJhIjoiY20zbGF0Y202MG9kbjJscGViOXFqOTVzOSJ9.pytJzzZE9jqg6wWHfHWOew";

const MapComponent = ({ latitude, longitude }) => {
  const mapContainerRef = useRef(null);

  useEffect(() => {
    if (!latitude || !longitude) return;

    // Initialize the Mapbox map
    const map = new mapboxgl.Map({
      container: mapContainerRef.current,
      style: 'mapbox://styles/mapbox/streets-v11', // Style of the map
      center: [longitude, latitude], // Center map on the given coordinates
      zoom: 14, // Initial zoom level
    });

    // Add a marker to the map
    new mapboxgl.Marker()
      .setLngLat([longitude, latitude])
      .addTo(map);

    // Cleanup on unmount
    return () => map.remove();
  }, [latitude, longitude]);

  return (
    <div
      ref={mapContainerRef}
      style={{ width: '100%', height: '400px', border: '1px solid #ddd', marginTop: '20px' }}
    ></div>
  );
};

export default MapComponent;
